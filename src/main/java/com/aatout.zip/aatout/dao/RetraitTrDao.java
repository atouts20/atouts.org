package com.aatout.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aatout.model.RetraitTR;

public interface RetraitTrDao extends JpaRepository<RetraitTR, Long> {

}
