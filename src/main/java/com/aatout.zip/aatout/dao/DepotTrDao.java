package com.aatout.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aatout.model.DepotTR;

public interface DepotTrDao extends JpaRepository<DepotTR, Long> {

}
