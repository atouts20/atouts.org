package com.aatout.web;

public class ResoldeForm {
	
	private Double mntVal;
	private Double mntMon;
	private String username;
	public Double getMntVal() {
		return mntVal;
	}
	public void setMntVal(Double mntVal) {
		this.mntVal = mntVal;
	}
	public Double getMntMon() {
		return mntMon;
	}
	public void setMntMon(Double mntMon) {
		this.mntMon = mntMon;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

}
