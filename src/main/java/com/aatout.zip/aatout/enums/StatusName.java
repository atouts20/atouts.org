package com.aatout.enums;

public enum StatusName {
	NON_AUTORISEE,
	REJETEE,
	AUTORISEE,
	VALIDEE
}
