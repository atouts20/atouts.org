package com.aatout.commande.model;

public class DestockageForm {
    private Long id;
    private double quantite;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public double getQuantite() {
		return quantite;
	}
	public void setQuantite(double quantite) {
		this.quantite = quantite;
	}
	public DestockageForm() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
