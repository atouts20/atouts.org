package com.aatout.security;

public class SecurityConstants {
	public static final String SECRET = "ramichpro@gmail.com";
	public static final long EXPIRATION_TIME = 864_000_000; //10jours
	public static final String TKEN_PREFIX = "Bearer ";
	public static final String HEADER_STRING = "Authorization";
}
