package com.aatout.message;

public interface EnvoiSms {
	void sendSms(SmsRequest smsRequest);

}
