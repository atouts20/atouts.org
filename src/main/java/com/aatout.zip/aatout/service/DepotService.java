package com.aatout.service;


import com.aatout.model.Depot;

public interface DepotService {
	public Depot saveDepot(Depot depot);
	
}
