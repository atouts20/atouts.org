package com.aatout.service;

public class MesConstants {
	public static final long EXPIRATION_TIME_TOKEN = 172_800_000; //2jours

}
