package com.aatout.random;

public interface RandomCodeService {
	public Long pin();
	public String pinString(int length);

}
